//
//  ViewController.swift
//  Video 4
//
//  Created by Jun  Nakasone on 17/09/17.
//  Copyright © 2017 Jun  Nakasone. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: IBOutlets
    // ========================================================================
    @IBOutlet weak var lblNome: UILabel!
    
    @IBOutlet weak var txtNome: UITextField!
    
    @IBOutlet weak var btnAlterar: UIButton!
    // ========================================================================
    
    
    // MARK: Ciclo de Vida da View Controller
    // ========================================================================

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    // ========================================================================
    
    
    
    // MARK: IBActions
    // ========================================================================
    
    @IBAction func alterarNome(sender: AnyObject)
    {
        lblNome.text = txtNome.text
        txtNome.text = ""
    }
    
    // ========================================================================


}

