//
//  ViewController.swift
//  Video2
//
//  Created by Jun  Nakasone on 16/09/17.
//  Copyright © 2017 Jun  Nakasone. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    // MARK: VARIAVEIS
    
    // MARK: CICLO DE VIDA DA VIEW CONTROLLER
    //=========================================================================
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(animated: Bool) {
        //
    }
    
    //=========================================================================
    
    // MARK: METODOS

}

